// transport_vehicle.cpp
#include "transport_vehicle.h"
#include "permit.h"  // Include the complete definition of the Permit class

TransportVehicle::TransportVehicle(std::shared_ptr<Permit> permit, VehicleType vehicle_type, int seat_count, int stops_count)
    : _permit(permit), _vehicle_type(vehicle_type), _seat_count(seat_count), _stops_count(stops_count) {}

const std::string& TransportVehicle::getPermitNumber() const {
    return _permit->getPermitNumber();
}

VehicleType TransportVehicle::getVehicleType() const {
    return _vehicle_type;
}

int TransportVehicle::getSeatCount() const {
    return _seat_count;
}

int TransportVehicle::getStopsCount() const {
    return _stops_count;
}
