// functionalities.cpp
#include <iostream>
#include <thread>
#include <vector>
#include <algorithm>
#include <numeric>
#include <functional>
#include <optional>
#include <mutex> // Add mutex for thread safety
#include "transport_vehicle.h"
#include "permit.h"  // Include the complete definition of the Permit class

// Global mutex for thread safety
std::mutex gMutex;

// Function to create TransportVehicle instances on the heap and store them in a shared pointer container
std::vector<std::shared_ptr<TransportVehicle>> createTransportVehicles() {
    // Create Permit instances
    auto permit1 = std::make_shared<Permit>("P001", 6);
    auto permit2 = std::make_shared<Permit>("P002", 12);
    auto permit3 = std::make_shared<Permit>("P003", 9);
    auto permit4 = std::make_shared<Permit>("P004", 8);

    // Create TransportVehicle instances on the heap
    auto vehicle1 = std::make_shared<TransportVehicle>(permit1, VehicleType::BUS, 50, 10);
    auto vehicle2 = std::make_shared<TransportVehicle>(permit2, VehicleType::CAB, 4, 5);
    auto vehicle3 = std::make_shared<TransportVehicle>(permit3, VehicleType::MINI_VAN, 8, 7);
    auto vehicle4 = std::make_shared<TransportVehicle>(permit4, VehicleType::BUS, 40, 12);

    // Store instances in a fixed-sized container
    return {vehicle1, vehicle2, vehicle3, vehicle4};
}

// Function to find and display the permit number for the instance at index position N
std::optional<std::string> findAndDisplayPermitNumber(const std::vector<std::shared_ptr<TransportVehicle>>& vehicles, size_t index) {
    if (index < vehicles.size()) {
        return vehicles[index]->getPermitNumber();
    }
    return std::nullopt; // Handle the case where the index is out of bounds
}

// Function to find and print the average seat count for a specific vehicle type

std::optional<double> findAndPrintAverageSeatCount(const std::vector<std::shared_ptr<TransportVehicle>>& vehicles, VehicleType vehicleType) {
    // Filter vehicles based on vehicleType
    std::vector<std::shared_ptr<TransportVehicle>> filteredVehicles;
    std::copy_if(vehicles.begin(), vehicles.end(), std::back_inserter(filteredVehicles), [vehicleType](const auto& vehicle) {
        return vehicle->getVehicleType() == vehicleType;
    });

    // Collect seat counts
    std::vector<int> seatCounts;
    seatCounts.reserve(filteredVehicles.size());
    for (const auto& vehicle : filteredVehicles) {
        seatCounts.push_back(vehicle->getSeatCount());
    }

    // Calculate average seat count
    if (!seatCounts.empty()) {
        double averageSeatCount = std::accumulate(seatCounts.begin(), seatCounts.end(), 0.0) / seatCounts.size();
        return averageSeatCount;
    } else {
        return std::nullopt; // Empty vector, no average seat count
    }
}



// Function to find and print true or false indicating whether all instances have the same vehicle type
std::optional<bool> findAndPrintSameVehicleType(const std::vector<std::shared_ptr<TransportVehicle>>& vehicles) {
    std::lock_guard<std::mutex> lock(gMutex); // Lock the mutex for thread safety

    if (std::adjacent_find(vehicles.begin(), vehicles.end(),
                           [](const auto& v1, const auto& v2) { return v1->getVehicleType() != v2->getVehicleType(); }) == vehicles.end()) {
        std::cout << "All instances have the same vehicle type." << std::endl;
        return true;
    }
    std::cout << "Not all instances have the same vehicle type." << std::endl;
    return false;
}

int main() {
    // ... (Same as before)

    // Create threads for each functionality
    std::vector<std::thread> threads;

    // Functionality 1: Create TransportVehicle instances on the heap
    auto vehicles = createTransportVehicles();

    // Functionality 2: Find and display the permit number for the instance at index position N
    threads.emplace_back([](const auto& vehicles, size_t index) {
        auto permitNumber = findAndDisplayPermitNumber(vehicles, index);
        if (permitNumber) {
            std::cout << "Permit number at index " << index << ": " << *permitNumber << std::endl;
        } else {
            std::cout << "Invalid index." << std::endl;
        }
    }, std::cref(vehicles), 2);

    // Functionality 3: Find and print the average seat count for the specified vehicle type
    threads.emplace_back([](const auto& vehicles, VehicleType vehicleType) {
        auto averageSeatCount = findAndPrintAverageSeatCount(vehicles, vehicleType);
        if (!averageSeatCount) {
            std::cout << "No instances found for the specified vehicle type." << std::endl;
        }
    }, std::cref(vehicles), VehicleType::BUS);

    // Functionality 4: Find and print true or false indicating whether all instances have the same vehicle type
    threads.emplace_back([](const auto& vehicles) {
        auto sameVehicleType = findAndPrintSameVehicleType(vehicles);
        if (!sameVehicleType) {
            // Handle the case where not all instances have the same vehicle type
        }
    }, std::cref(vehicles));

    // Join threads
    for (auto& thread : threads) {
        thread.join();
    }

    return 0;
}
