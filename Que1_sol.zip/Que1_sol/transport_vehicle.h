// transport_vehicle.h
#pragma once

#include <memory>
#include <string>

// Forward declaration of Permit class
class Permit;

enum class VehicleType {
    BUS,
    CAB,
    MINI_VAN
};

class TransportVehicle {
public:
    TransportVehicle(std::shared_ptr<Permit> permit, VehicleType vehicle_type, int seat_count, int stops_count);

    const std::string& getPermitNumber() const;
    VehicleType getVehicleType() const;
    int getSeatCount() const;
    int getStopsCount() const;

private:
    std::shared_ptr<Permit> _permit;
    VehicleType _vehicle_type;
    int _seat_count;
    int _stops_count;
};
